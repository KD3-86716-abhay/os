rev file.txt > file1.txt
