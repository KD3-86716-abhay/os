#!\bin\bash
echo "Hidden files in the current directory"

ls -a|grep "^\."

