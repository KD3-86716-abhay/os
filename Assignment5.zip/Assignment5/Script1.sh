#!/bin/bash
#--------------
#Aim: prime or not
#--------------

for(())	
do 
	ifequal cond check ()
	
	fi
	if(mod checking )
	
	fi()

done







